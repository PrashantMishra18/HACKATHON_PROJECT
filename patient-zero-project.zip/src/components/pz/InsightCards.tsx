import { cn } from "@/lib/utils";
import type { Insight, InsightKind, SourceDoc } from "@/lib/types";
import { ConfidenceBadge, Eyebrow, GlassCard, SourceChips } from "./primitives";

const KIND: Record<InsightKind, { label: string; eyebrow: string; border: string }> = {
  insight: { label: "Sourced insight", eyebrow: "text-cyan", border: "" },
  link: { label: "Cross-document link", eyebrow: "text-brand", border: "" },
  uncertainty: { label: "Uncertainty note", eyebrow: "text-subtle", border: "" },
  gap: { label: "Missing information", eyebrow: "text-warn", border: "border-warn/30" },
  inconsistency: { label: "Inconsistency", eyebrow: "text-signal", border: "border-signal/40" },
};

export function InsightCards({
  insights,
  docs,
  onHover,
}: {
  insights: Insight[];
  docs: SourceDoc[];
  onHover: (id: string | null) => void;
}) {
  return (
    <section>
      <div className="flex items-end justify-between px-1">
        <div>
          <Eyebrow>Sourced insights</Eyebrow>
          <h2 className="mt-1 font-display text-xl font-bold tracking-tight text-primary">
            Every claim traces to a document
          </h2>
        </div>
        <p className="hidden text-[11px] text-faint sm:block">{insights.length} findings · hover a chip to locate its source</p>
      </div>

      <div className="mt-5 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {insights.map((ins, i) => {
          const k = KIND[ins.kind];
          return (
            <GlassCard
              key={ins.id}
              tilt={i % 2 === 0 ? "left" : "right"}
              className={cn("animate-rise rounded-2xl p-5", k.border)}
            >
              <div className="flex items-center justify-between">
                <p className={cn("eyebrow", k.eyebrow)}>{k.label}</p>
                <ConfidenceBadge level={ins.confidence} />
              </div>
              <p className="mt-2 text-sm leading-relaxed text-foreground/90">{ins.text}</p>
              <SourceChips sources={ins.sources} docs={docs} onHover={onHover} className="mt-3" />
            </GlassCard>
          );
        })}
      </div>
    </section>
  );
}
