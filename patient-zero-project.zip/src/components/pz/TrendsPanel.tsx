import { LineChart, Line, ReferenceArea, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ArrowDownRight, ArrowUpRight, Minus } from "lucide-react";
import { cn } from "@/lib/utils";
import type { SourceDoc, TrendSeries } from "@/lib/types";
import { fmtDate, fmtDateFull } from "@/lib/analyze";
import { Eyebrow, GlassCard, SourceChips } from "./primitives";

export function TrendsPanel({
  trends,
  docs,
  onHover,
}: {
  trends: TrendSeries[];
  docs: SourceDoc[];
  onHover: (id: string | null) => void;
}) {
  return (
    <GlassCard tilt="left" className="p-6">
      <Eyebrow>Repeated tests</Eyebrow>
      <h2 className="mt-1 font-display text-xl font-bold tracking-tight text-primary">Trends across reports</h2>

      {trends.length === 0 && (
        <p className="mt-4 text-sm text-faint">A test needs two or more dated results before a trend appears.</p>
      )}

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        {trends.map((t) => {
          const last = t.points[t.points.length - 1]!;
          const data = t.points.map((p) => ({ ...p, label: fmtDate(p.date) }));
          const Icon = t.direction === "up" ? ArrowUpRight : t.direction === "down" ? ArrowDownRight : Minus;
          const bad = last.outOfRange;
          const vals = t.points.map((p) => p.value);
          const lo = Math.min(...vals, t.refLow ?? Infinity);
          const hi = Math.max(...vals, t.refHigh ?? -Infinity);
          const pad = (hi - lo || 1) * 0.2;
          return (
            <div key={t.test} className="rounded-2xl border border-glass-border bg-glass p-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-sm font-semibold text-foreground">{t.test}</p>
                  <p className="text-[11px] text-faint">{t.points.length} readings · {fmtDate(t.points[0]!.date)} → {fmtDate(last.date)}</p>
                </div>
                <div className="text-right">
                  <p className={cn("font-display text-2xl leading-none font-bold", bad ? "text-signal" : "text-primary")}>
                    {last.value}
                    <span className="ml-0.5 text-xs font-medium text-faint">{t.unit}</span>
                  </p>
                  <p className={cn("mt-1 inline-flex items-center gap-0.5 text-[11px] font-medium", bad ? "text-signal" : "text-success")}>
                    <Icon className="size-3" />
                    {t.delta > 0 ? "+" : ""}{t.delta} {t.unit}
                  </p>
                </div>
              </div>
              <div className="mt-3 h-24">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data} margin={{ top: 6, right: 8, bottom: 0, left: 8 }}>
                    {t.refLow != null && t.refHigh != null && (
                      <ReferenceArea y1={t.refLow} y2={t.refHigh} fill="var(--success)" fillOpacity={0.08} strokeOpacity={0} />
                    )}
                    <XAxis dataKey="label" tick={{ fontSize: 10, fill: "var(--faint)" }} axisLine={false} tickLine={false} />
                    <YAxis hide domain={[lo - pad, hi + pad]} />
                    <Tooltip
                      cursor={{ stroke: "var(--glass-border)" }}
                      contentStyle={{ background: "var(--popover)", border: "1px solid var(--glass-border)", borderRadius: 12, fontSize: 12, color: "var(--foreground)" }}
                      labelStyle={{ color: "var(--subtle)" }}
                      formatter={(v: number, _n, p) => [`${v} ${t.unit ?? ""} · ${p.payload.confidence} confidence`, fmtDateFull(p.payload.date)]}
                    />
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke={bad ? "var(--signal)" : "var(--cyan)"}
                      strokeWidth={2.5}
                      dot={{ r: 3.5, strokeWidth: 0, fill: bad ? "var(--signal)" : "var(--cyan)" }}
                      activeDot={{ r: 5 }}
                      isAnimationActive
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <SourceChips sources={t.points.map((p) => p.source)} docs={docs} onHover={onHover} className="mt-2" />
            </div>
          );
        })}
      </div>
    </GlassCard>
  );
}
