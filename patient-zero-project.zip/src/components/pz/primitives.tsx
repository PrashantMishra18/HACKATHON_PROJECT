import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import type { Confidence, Provenance, SourceDoc } from "@/lib/types";

export function GlassCard({
  children,
  className,
  tilt = "none",
  sheen = false,
}: {
  children: ReactNode;
  className?: string;
  tilt?: "left" | "right" | "none";
  sheen?: boolean;
}) {
  return (
    <div
      className={cn(
        "glass relative overflow-hidden rounded-3xl",
        tilt === "left" && "-rotate-1",
        tilt === "right" && "rotate-[0.5deg]",
        className,
      )}
    >
      {sheen && (
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="animate-sheen absolute top-0 left-0 h-full w-1/3 bg-gradient-to-r from-glass-strong to-transparent" />
        </div>
      )}
      <div className="relative">{children}</div>
    </div>
  );
}

export function Eyebrow({ children, className }: { children: ReactNode; className?: string }) {
  return <p className={cn("eyebrow text-cyan", className)}>{children}</p>;
}

const CONF_STYLES: Record<Confidence, string> = {
  high: "text-success",
  medium: "text-warn",
  low: "text-signal",
};
const CONF_DOT: Record<Confidence, string> = {
  high: "bg-success",
  medium: "bg-warn",
  low: "bg-signal",
};

export function ConfidenceBadge({ level, className }: { level: Confidence; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1.5 text-[11px] font-semibold capitalize", CONF_STYLES[level], className)}>
      <span className={cn("size-1.5 rounded-full", CONF_DOT[level])} />
      {level}
    </span>
  );
}

export function SourceChips({
  sources,
  docs,
  onHover,
  className,
}: {
  sources: Provenance[];
  docs: SourceDoc[];
  onHover?: (docId: string | null) => void;
  className?: string;
}) {
  const seen = new Set<string>();
  const unique = sources.filter((s) => {
    const k = `${s.docId}|${s.page ?? ""}`;
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
  return (
    <div className={cn("flex flex-wrap gap-1.5", className)}>
      {unique.map((s, i) => {
        const doc = docs.find((d) => d.id === s.docId);
        const label = doc ? shortName(doc.name) : "Unknown source";
        return (
          <span
            key={i}
            title={s.quote ? `“${s.quote}”` : doc?.name}
            onMouseEnter={() => onHover?.(s.docId)}
            onMouseLeave={() => onHover?.(null)}
            className="inline-flex cursor-default items-center gap-1 rounded-full border border-glass-border bg-glass px-2 py-0.5 text-[10.5px] text-subtle transition-colors hover:border-cyan/50 hover:text-foreground"
          >
            <span className="size-1 rounded-full bg-cyan" />
            {label}
            {s.page ? <span className="text-faint">· p.{s.page}</span> : null}
          </span>
        );
      })}
    </div>
  );
}

export function shortName(name: string) {
  return name.replace(/\.[a-z0-9]+$/i, "").replace(/\s*[—-]\s*/g, " · ");
}
