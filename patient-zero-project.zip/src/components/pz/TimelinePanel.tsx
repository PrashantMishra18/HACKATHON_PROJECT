import { useState } from "react";
import { cn } from "@/lib/utils";
import type { SourceDoc, TimelineItem, TimelineKind } from "@/lib/types";
import { fmtDateFull } from "@/lib/analyze";
import { ConfidenceBadge, Eyebrow, GlassCard, SourceChips } from "./primitives";

const DOT: Record<string, string> = {
  lab: "bg-brand ring-brand/20",
  medication: "bg-cyan ring-cyan/20",
  event: "bg-success ring-success/20",
  signal: "bg-signal ring-signal/20",
  warn: "bg-warn ring-warn/20",
};

const FILTERS: { key: TimelineKind | "all"; label: string }[] = [
  { key: "all", label: "All" },
  { key: "lab", label: "Labs" },
  { key: "medication", label: "Medications" },
  { key: "event", label: "Visits & findings" },
  { key: "alert", label: "Alerts" },
];

export function TimelinePanel({
  items,
  docs,
  onHover,
}: {
  items: TimelineItem[];
  docs: SourceDoc[];
  onHover: (id: string | null) => void;
}) {
  const [filter, setFilter] = useState<TimelineKind | "all">("all");
  const shown = items.filter((i) => filter === "all" || i.kind === filter);

  return (
    <GlassCard tilt="right" className="p-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <Eyebrow>Longitudinal timeline</Eyebrow>
          <h2 className="mt-1 font-display text-xl font-bold tracking-tight text-primary">
            Recurring tests &amp; medication shifts
          </h2>
        </div>
        <div className="hidden items-center gap-3 text-[11px] text-subtle sm:flex">
          <Legend className="bg-brand">Lab</Legend>
          <Legend className="bg-cyan">Med</Legend>
          <Legend className="bg-success">Visit</Legend>
          <Legend className="bg-signal">Alert</Legend>
        </div>
      </div>

      <div className="mt-4 flex flex-wrap gap-1.5">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={cn(
              "rounded-full border px-3 py-1 text-[11px] font-medium transition-colors",
              filter === f.key
                ? "border-primary/40 bg-primary text-primary-foreground"
                : "border-glass-border bg-glass text-subtle hover:text-foreground",
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="relative mt-6">
        <div className="bg-timeline-rail absolute top-2 bottom-2 left-[7px] w-px" />
        {shown.length === 0 && (
          <p className="pl-8 text-sm text-faint">Nothing here yet — upload a document to populate the timeline.</p>
        )}
        <div className="space-y-5">
          {shown.map((item, i) => {
            const dotKey = item.kind === "alert" ? (item.severity ?? "signal") : item.kind;
            return (
              <div
                key={item.id}
                className="animate-rise relative pl-8"
                style={{ animationDelay: `${Math.min(i, 12) * 40}ms` }}
              >
                <span className={cn("absolute top-1 left-0 size-3.5 rounded-full ring-4", DOT[dotKey])} />
                <div className="flex flex-wrap items-baseline justify-between gap-x-3">
                  <p className="text-xs text-faint">{fmtDateFull(item.date)}</p>
                  <ConfidenceBadge level={item.confidence} />
                </div>
                <p
                  className={cn(
                    "mt-0.5 text-sm text-foreground",
                    item.kind === "alert" && item.severity === "signal" && "font-semibold text-signal",
                    item.kind === "alert" && item.severity === "warn" && "font-semibold text-warn",
                  )}
                >
                  {item.title}
                </p>
                {item.detail && <p className="mt-0.5 text-[13px] text-subtle">{item.detail}</p>}
                <SourceChips sources={item.sources} docs={docs} onHover={onHover} className="mt-2" />
              </div>
            );
          })}
        </div>
      </div>
    </GlassCard>
  );
}

function Legend({ children, className }: { children: string; className: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className={cn("size-2 rounded-full", className)} />
      {children}
    </span>
  );
}
