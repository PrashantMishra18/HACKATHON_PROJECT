import { cn } from "@/lib/utils";
import type { MedTimelineEntry, SourceDoc } from "@/lib/types";
import { fmtDate } from "@/lib/analyze";
import { ConfidenceBadge, Eyebrow, GlassCard, SourceChips } from "./primitives";

const ACTION_LABEL: Record<string, string> = {
  started: "Started", changed: "Changed", continued: "Continued", stopped: "Stopped", mentioned: "Mentioned",
};

export function MedicationPanel({
  meds,
  docs,
  onHover,
}: {
  meds: MedTimelineEntry[];
  docs: SourceDoc[];
  onHover: (id: string | null) => void;
}) {
  return (
    <GlassCard tilt="right" className="p-6">
      <Eyebrow>Medication history</Eyebrow>
      <h2 className="mt-1 font-display text-xl font-bold tracking-tight text-primary">Starts, changes &amp; conflicts</h2>

      {meds.length === 0 && <p className="mt-4 text-sm text-faint">No medications extracted yet.</p>}

      <div className="mt-5 space-y-4">
        {meds.map((m) => (
          <div key={m.name} className={cn("rounded-2xl border bg-glass p-4", m.conflict ? "border-signal/40" : "border-glass-border")}>
            <div className="flex items-center justify-between gap-2">
              <p className="text-sm font-semibold text-foreground">{m.name}</p>
              <div className="flex items-center gap-2 text-[11px]">
                {m.conflict && <span className="rounded-full bg-signal/15 px-2 py-0.5 font-semibold text-signal">Conflict</span>}
                {m.changes > 0 && <span className="rounded-full bg-cyan/15 px-2 py-0.5 font-semibold text-cyan">{m.changes} change{m.changes > 1 ? "s" : ""}</span>}
                <span className="text-faint">{fmtDate(m.firstDate)} → {fmtDate(m.lastDate)}</span>
              </div>
            </div>
            <ol className="mt-3 flex flex-wrap gap-2">
              {m.records.map((r, i) => (
                <li key={i} className="flex min-w-0 items-center gap-2">
                  <div
                    onMouseEnter={() => onHover(r.source.docId)}
                    onMouseLeave={() => onHover(null)}
                    className={cn(
                      "rounded-xl border px-3 py-2 transition-colors hover:border-cyan/50",
                      r.action === "changed" ? "border-cyan/40" : "border-glass-border",
                    )}
                  >
                    <div className="flex items-center gap-2 text-[10.5px] text-faint">
                      <span>{fmtDate(r.date)}</span>
                      <span className="text-subtle">{ACTION_LABEL[r.action]}</span>
                      <ConfidenceBadge level={r.confidence} className="text-[10px]" />
                    </div>
                    <p className="mt-0.5 text-[13px] font-medium text-foreground">
                      {r.dose ?? <span className="text-warn">dose missing</span>} {r.frequency ?? ""}
                    </p>
                  </div>
                  {i < m.records.length - 1 && <span className="text-faint">→</span>}
                </li>
              ))}
            </ol>
            <SourceChips sources={m.records.map((r) => r.source)} docs={docs} onHover={onHover} className="mt-3" />
          </div>
        ))}
      </div>
    </GlassCard>
  );
}
