import type { Analysis, SourceDoc } from "@/lib/types";
import { ConfidenceBadge, Eyebrow, GlassCard } from "./primitives";
import { cn } from "@/lib/utils";

export function PatientCard({ analysis, docs }: { analysis: Analysis; docs: SourceDoc[] }) {
  const { identity, span, overallConfidence, insights } = analysis;
  const flagged = insights.filter((i) => i.kind === "inconsistency" || i.kind === "gap");
  const meta = [identity.mrn && `MRN ${identity.mrn}`, identity.age && `${identity.age}y`, identity.sex].filter(Boolean).join(" · ");

  return (
    <GlassCard tilt="left" sheen className="glass-strong p-6">
      <Eyebrow>Patient</Eyebrow>
      <h1 className="mt-2 font-display text-3xl leading-tight font-bold tracking-tight text-primary">
        {identity.name ?? "Unidentified patient"}
      </h1>
      <p className="mt-1 text-sm text-subtle">{meta || "No identity details extracted"}</p>

      <dl className="mt-6 space-y-3 text-sm">
        <Row label="Timeline span">{span.label}</Row>
        <Row label="Sources">{docs.filter((d) => d.status === "ready").length} documents</Row>
        <Row label="Repeated tests">{analysis.trends.length} tracked</Row>
        <Row label="Medications">{analysis.medications.length} tracked</Row>
        <Row label="Confidence"><ConfidenceBadge level={overallConfidence} className="text-sm" /></Row>
      </dl>

      <div className="mt-6 border-t border-glass-border pt-5">
        <p className="eyebrow text-faint">Flagged issues</p>
        <div className="mt-3 space-y-2">
          {flagged.length === 0 && <p className="text-sm text-subtle">No gaps or inconsistencies detected.</p>}
          {flagged.slice(0, 5).map((f) => (
            <div key={f.id} className="flex items-start gap-2 text-sm">
              <span className={cn("mt-1.5 size-2 shrink-0 rounded-full", f.kind === "inconsistency" ? "bg-signal" : "bg-warn")} />
              <span className="text-foreground/85">{shorten(f.text)}</span>
            </div>
          ))}
          {flagged.length > 5 && <p className="text-[11px] text-faint">+{flagged.length - 5} more below</p>}
        </div>
      </div>
    </GlassCard>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between">
      <dt className="text-subtle">{label}</dt>
      <dd className="font-semibold text-primary">{children}</dd>
    </div>
  );
}

function shorten(t: string) {
  const cut = t.split(/ — |: /)[0] ?? t;
  return cut.length > 70 ? cut.slice(0, 68) + "…" : cut;
}
