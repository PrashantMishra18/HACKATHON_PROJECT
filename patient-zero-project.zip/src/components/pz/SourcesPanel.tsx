import { useRef, useState } from "react";
import { FileText, Image as ImageIcon, Loader2, AlertTriangle, Upload, X } from "lucide-react";
import { cn } from "@/lib/utils";
import type { SourceDoc } from "@/lib/types";
import { fmtDateFull } from "@/lib/analyze";
import { Eyebrow, GlassCard, shortName } from "./primitives";

const TYPE_LABEL: Record<string, string> = {
  lab: "Lab", prescription: "Rx", imaging: "Imaging", visit: "Visit", discharge: "Discharge", other: "Doc",
};

export function SourcesPanel({
  docs,
  highlightId,
  onFiles,
  onRemove,
  onHover,
}: {
  docs: SourceDoc[];
  highlightId: string | null;
  onFiles: (files: File[]) => void;
  onRemove: (id: string) => void;
  onHover: (id: string | null) => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);

  return (
    <GlassCard className="p-6">
      <div className="flex items-center justify-between">
        <Eyebrow>Sources</Eyebrow>
        <span className="text-[11px] text-faint">{docs.length} document{docs.length === 1 ? "" : "s"}</span>
      </div>

      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => { e.preventDefault(); setDragging(false); onFiles(Array.from(e.dataTransfer.files)); }}
        onClick={() => inputRef.current?.click()}
        className={cn(
          "mt-4 flex cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-glass-border bg-glass px-4 py-6 text-center transition-colors hover:border-cyan/60 hover:bg-glass-strong",
          dragging && "border-cyan bg-glass-strong",
        )}
      >
        <div className="bg-brand-gradient grid size-9 place-items-center rounded-xl text-brand-foreground shadow-lg shadow-brand/30">
          <Upload className="size-4" />
        </div>
        <p className="text-sm font-medium text-foreground">Drop medical documents</p>
        <p className="text-[11px] text-faint">PDF, JPG, PNG or TXT · prescriptions, labs, scans, notes</p>
        <input
          ref={inputRef}
          type="file"
          multiple
          accept=".pdf,.png,.jpg,.jpeg,.webp,.txt,application/pdf,image/*,text/plain"
          className="hidden"
          onChange={(e) => { onFiles(Array.from(e.target.files ?? [])); e.target.value = ""; }}
        />
      </div>

      <ul className="mt-4 space-y-2">
        {docs.map((d) => {
          const ex = d.extraction;
          const isImg = /\.(png|jpe?g|webp)$/i.test(d.name);
          return (
            <li
              key={d.id}
              onMouseEnter={() => onHover(d.id)}
              onMouseLeave={() => onHover(null)}
              className={cn(
                "group flex items-start gap-3 rounded-xl border border-transparent px-2.5 py-2 transition-all",
                highlightId === d.id && "border-cyan/60 bg-glass-strong shadow-[0_0_0_4px_oklch(0.715_0.143_215.2/12%)]",
              )}
            >
              <div className="mt-0.5 grid size-8 shrink-0 place-items-center rounded-lg bg-glass-strong text-subtle">
                {d.status === "processing" ? (
                  <Loader2 className="size-4 animate-spin text-cyan" />
                ) : d.status === "error" ? (
                  <AlertTriangle className="size-4 text-signal" />
                ) : isImg ? (
                  <ImageIcon className="size-4" />
                ) : (
                  <FileText className="size-4" />
                )}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-foreground">{shortName(d.name)}</p>
                {d.status === "processing" && <p className="text-[11px] text-cyan">Extracting with AI…</p>}
                {d.status === "error" && <p className="text-[11px] text-signal">{d.error}</p>}
                {d.status === "ready" && ex && (
                  <p className="text-[11px] text-faint">
                    <span className="text-subtle">{TYPE_LABEL[ex.documentType]}</span> · {fmtDateFull(ex.documentDate)} ·{" "}
                    {ex.labs.length + ex.medications.length + ex.events.length} facts
                  </p>
                )}
              </div>
              <button
                aria-label={`Remove ${d.name}`}
                onClick={() => onRemove(d.id)}
                className="mt-1 rounded-md p-1 text-faint opacity-0 transition-opacity hover:text-foreground group-hover:opacity-100"
              >
                <X className="size-3.5" />
              </button>
            </li>
          );
        })}
      </ul>
    </GlassCard>
  );
}
