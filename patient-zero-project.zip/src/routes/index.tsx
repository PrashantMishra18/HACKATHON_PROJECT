import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMemo, useState } from "react";
import { Download, RotateCcw } from "lucide-react";
import { toast } from "sonner";

import type { SourceDoc } from "@/lib/types";
import { DEMO_DOCS } from "@/lib/demo-data";
import { analyze } from "@/lib/analyze";
import { extractDocument } from "@/lib/extract.functions";
import { PatientCard } from "@/components/pz/PatientCard";
import { SourcesPanel } from "@/components/pz/SourcesPanel";
import { TimelinePanel } from "@/components/pz/TimelinePanel";
import { TrendsPanel } from "@/components/pz/TrendsPanel";
import { MedicationPanel } from "@/components/pz/MedicationPanel";
import { InsightCards } from "@/components/pz/InsightCards";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Patient Zero — Longitudinal Patient Intelligence" },
      { name: "description", content: "Turn scattered prescriptions, lab reports and scans into one sourced patient timeline with trends, medication history, gaps and inconsistencies." },
      { property: "og:title", content: "Patient Zero — Longitudinal Patient Intelligence" },
      { property: "og:description", content: "Medical documents → extraction → timeline → relationships → sourced insights." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const MAX_BYTES = 8 * 1024 * 1024;

function readFile(file: File): Promise<{ dataUrl?: string; text?: string }> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onerror = () => reject(new Error("Could not read file"));
    if (file.type === "text/plain" || /\.txt$/i.test(file.name)) {
      r.onload = () => resolve({ text: String(r.result) });
      r.readAsText(file);
    } else {
      r.onload = () => resolve({ dataUrl: String(r.result) });
      r.readAsDataURL(file);
    }
  });
}

function Index() {
  const [docs, setDocs] = useState<SourceDoc[]>(DEMO_DOCS);
  const [highlight, setHighlight] = useState<string | null>(null);
  const extract = useServerFn(extractDocument);

  const analysis = useMemo(() => analyze(docs), [docs]);
  const processing = docs.filter((d) => d.status === "processing").length;
  const flaggedCount = analysis.insights.filter((i) => i.kind === "gap" || i.kind === "inconsistency").length;

  async function handleFiles(files: File[]) {
    for (const file of files) {
      const id = `u-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      if (file.size > MAX_BYTES) {
        toast.error(`${file.name} is larger than 8 MB.`);
        continue;
      }
      setDocs((d) => [...d, { id, name: file.name, status: "processing" }]);
      try {
        const payload = await readFile(file);
        const mimeType = file.type || (/\.pdf$/i.test(file.name) ? "application/pdf" : /\.txt$/i.test(file.name) ? "text/plain" : "application/octet-stream");
        const ex = await extract({ data: { name: file.name, mimeType, ...payload } });
        const stamp = <T extends { source: { docId: string } }>(rows: T[]) => rows.map((r) => ({ ...r, source: { ...r.source, docId: id } }));
        const extraction = { ...ex, labs: stamp(ex.labs), medications: stamp(ex.medications), events: stamp(ex.events) };
        setDocs((d) => d.map((x) => (x.id === id ? { ...x, status: "ready", extraction } : x)));
        toast.success(`${file.name}: ${extraction.labs.length} results, ${extraction.medications.length} medications, ${extraction.events.length} events extracted.`);
      } catch (e) {
        const msg = e instanceof Error ? e.message : "Extraction failed";
        setDocs((d) => d.map((x) => (x.id === id ? { ...x, status: "error", error: msg } : x)));
        toast.error(msg);
      }
    }
  }

  function exportReport() {
    const blob = new Blob([JSON.stringify({ generatedAt: new Date().toISOString(), documents: docs, analysis }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = Object.assign(document.createElement("a"), { href: url, download: "patient-zero-report.json" });
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-ink font-sans text-foreground">
      {/* Ambient glows */}
      <div className="pointer-events-none absolute inset-0">
        <div className="animate-glow-drift absolute -top-40 -left-32 size-[520px] rounded-full bg-brand/25 blur-[120px]" />
        <div className="animate-glow-drift-b absolute -right-[120px] -bottom-[160px] size-[560px] rounded-full bg-cyan/20 blur-[130px]" />
        <div className="absolute top-1/3 right-1/4 size-[300px] rounded-full bg-signal/10 blur-[100px]" />
      </div>

      <div className="relative z-10 mx-auto max-w-[1440px] px-6 py-8 lg:px-10">
        <header className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-brand-gradient grid size-10 place-items-center rounded-xl font-display text-lg font-bold text-brand-foreground shadow-lg shadow-brand/30">
              P0
            </div>
            <div>
              <p className="font-display text-lg leading-none font-bold tracking-tight text-primary">Patient Zero</p>
              <p className="mt-1 text-[11px] tracking-[0.18em] text-subtle uppercase">Longitudinal Patient Intelligence</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden items-center gap-2 rounded-full border border-glass-border bg-glass px-3 py-1.5 text-xs text-foreground/80 md:flex">
              <span className="animate-pulse-dot size-2 rounded-full bg-cyan" />
              {processing > 0
                ? `Extracting ${processing} document${processing > 1 ? "s" : ""}…`
                : `${docs.filter((d) => d.status === "ready").length} documents linked · ${flaggedCount} issue${flaggedCount === 1 ? "" : "s"} flagged`}
            </div>
            <button
              onClick={() => { setDocs(DEMO_DOCS); toast("Demo patient restored."); }}
              className="inline-flex items-center gap-1.5 rounded-full border border-glass-border bg-glass px-3.5 py-2 text-sm font-medium text-foreground/80 transition-colors hover:bg-glass-strong hover:text-foreground"
            >
              <RotateCcw className="size-3.5" /> Demo
            </button>
            <button
              onClick={exportReport}
              className="inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/10 transition-transform hover:scale-[1.02]"
            >
              <Download className="size-3.5" /> Export report
            </button>
          </div>
        </header>

        <p className="mt-6 hidden text-[11px] tracking-[0.2em] text-faint uppercase lg:block">
          Documents → Extraction → Timeline → Relationships → Sourced insights
        </p>

        <section className="mt-6 grid gap-6 lg:grid-cols-12">
          <div className="space-y-6 lg:col-span-4">
            <PatientCard analysis={analysis} docs={docs} />
            <SourcesPanel
              docs={docs}
              highlightId={highlight}
              onFiles={handleFiles}
              onRemove={(id) => setDocs((d) => d.filter((x) => x.id !== id))}
              onHover={setHighlight}
            />
          </div>
          <div className="lg:col-span-8">
            <TimelinePanel items={analysis.timeline} docs={docs} onHover={setHighlight} />
          </div>
        </section>

        <section className="mt-6 grid gap-6 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <TrendsPanel trends={analysis.trends} docs={docs} onHover={setHighlight} />
          </div>
          <div className="lg:col-span-5">
            <MedicationPanel meds={analysis.medications} docs={docs} onHover={setHighlight} />
          </div>
        </section>

        <div className="mt-10">
          <InsightCards insights={analysis.insights} docs={docs} onHover={setHighlight} />
        </div>

        <footer className="mt-12 border-t border-glass-border pt-5 text-[11px] text-faint">
          Patient Zero preserves uncertainty: every extracted value carries a confidence level and a source citation. Ambiguous values are excluded from trends and surfaced for human review. Not a substitute for clinical judgement.
        </footer>
      </div>
    </div>
  );
}
