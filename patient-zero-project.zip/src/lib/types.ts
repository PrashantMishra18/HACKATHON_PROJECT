export type DocType =
  | "lab"
  | "prescription"
  | "imaging"
  | "visit"
  | "discharge"
  | "other";

export type Confidence = "high" | "medium" | "low";

export interface Provenance {
  docId: string;
  page?: number | undefined;
  quote?: string | undefined;
}

export interface LabResult {
  test: string;
  value: number | null;
  rawValue?: string | undefined;
  unit?: string | undefined;
  refLow?: number | null | undefined;
  refHigh?: number | null | undefined;
  date: string; // ISO yyyy-mm-dd
  confidence: Confidence;
  source: Provenance;
}

export type MedAction = "started" | "continued" | "changed" | "stopped" | "mentioned";

export interface Medication {
  name: string;
  dose?: string | undefined;
  frequency?: string | undefined;
  action: MedAction;
  date: string;
  confidence: Confidence;
  source: Provenance;
}

export interface ClinicalEvent {
  kind: "visit" | "diagnosis" | "imaging" | "procedure" | "symptom" | "note";
  title: string;
  detail?: string | undefined;
  date: string;
  confidence: Confidence;
  source: Provenance;
}

export interface PatientIdentity {
  name?: string | undefined;
  age?: number | undefined;
  sex?: string | undefined;
  mrn?: string | undefined;
}

export interface Extraction {
  patient?: PatientIdentity | undefined;
  documentDate?: string | undefined;
  documentType: DocType;
  summary: string;
  labs: LabResult[];
  medications: Medication[];
  events: ClinicalEvent[];
  uncertainties: string[];
}

export interface SourceDoc {
  id: string;
  name: string;
  status: "processing" | "ready" | "error";
  extraction?: Extraction | undefined;
  error?: string | undefined;
}

/* ---------- Derived analysis ---------- */

export type TimelineKind = "lab" | "medication" | "event" | "alert";

export interface TimelineItem {
  id: string;
  kind: TimelineKind;
  date: string;
  title: string;
  detail?: string | undefined;
  confidence: Confidence;
  sources: Provenance[];
  severity?: "warn" | "signal" | undefined;
}

export interface TrendPoint {
  date: string;
  value: number;
  unit?: string | undefined;
  confidence: Confidence;
  source: Provenance;
  outOfRange?: boolean | undefined;
}

export interface TrendSeries {
  test: string;
  unit?: string | undefined;
  points: TrendPoint[];
  delta: number;
  direction: "up" | "down" | "flat";
  refLow?: number | null | undefined;
  refHigh?: number | null | undefined;
}

export interface MedTimelineEntry {
  name: string;
  records: Medication[];
  changes: number;
  conflict?: boolean | undefined;
  firstDate: string;
  lastDate: string;
}

export type InsightKind = "insight" | "link" | "uncertainty" | "gap" | "inconsistency";

export interface Insight {
  id: string;
  kind: InsightKind;
  text: string;
  confidence: Confidence;
  sources: Provenance[];
  date?: string | undefined;
}

export interface Analysis {
  timeline: TimelineItem[];
  trends: TrendSeries[];
  medications: MedTimelineEntry[];
  insights: Insight[];
  identity: PatientIdentity;
  span: { start?: string | undefined; end?: string | undefined; label: string };
  overallConfidence: Confidence;
}
