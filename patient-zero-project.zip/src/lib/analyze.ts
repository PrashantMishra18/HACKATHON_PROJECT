import type {
  Analysis,
  Confidence,
  Insight,
  LabResult,
  MedTimelineEntry,
  Medication,
  PatientIdentity,
  Provenance,
  SourceDoc,
  TimelineItem,
  TrendSeries,
} from "./types";

/* ---------- helpers ---------- */

const RANK: Record<Confidence, number> = { high: 3, medium: 2, low: 1 };
export const minConfidence = (...c: Confidence[]): Confidence =>
  c.reduce((a, b) => (RANK[b] < RANK[a] ? b : a), "high");

const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();

const TEST_ALIASES: Record<string, string> = {
  hba1c: "HbA1c", "hemoglobin a1c": "HbA1c", "glycated hemoglobin": "HbA1c", "glycated haemoglobin": "HbA1c", a1c: "HbA1c",
  "fasting glucose": "Fasting glucose", "fasting plasma glucose": "Fasting glucose", fpg: "Fasting glucose", fbs: "Fasting glucose", "fasting blood sugar": "Fasting glucose", "fasting blood glucose": "Fasting glucose",
  ldl: "LDL cholesterol", "ldl cholesterol": "LDL cholesterol", "ldl c": "LDL cholesterol",
  creatinine: "Creatinine", "serum creatinine": "Creatinine",
  "systolic bp": "Systolic BP", "systolic blood pressure": "Systolic BP", sbp: "Systolic BP",
  "diastolic bp": "Diastolic BP", "diastolic blood pressure": "Diastolic BP", dbp: "Diastolic BP",
  tsh: "TSH", hemoglobin: "Hemoglobin", haemoglobin: "Hemoglobin", hb: "Hemoglobin",
};
export const canonicalTest = (t: string) => TEST_ALIASES[norm(t)] ?? t.trim();
const canonicalMed = (m: string) => {
  const n = norm(m).split(" ")[0] ?? m;
  return n.charAt(0).toUpperCase() + n.slice(1);
};

/** Expected repeat interval in days for common monitoring tests. */
const EXPECTED_INTERVAL: Record<string, number> = {
  HbA1c: 180, "Fasting glucose": 180, "LDL cholesterol": 365, Creatinine: 365, "Systolic BP": 180, "Diastolic BP": 180,
};

/** Medication class → tests it is expected to move. */
const MED_TARGETS: { match: RegExp; tests: string[]; label: string }[] = [
  { match: /metformin|glipizide|gliclazide|glimepiride|sitagliptin|empagliflozin|dapagliflozin|insulin|pioglitazone/, tests: ["HbA1c", "Fasting glucose"], label: "glycaemic control" },
  { match: /lisinopril|enalapril|ramipril|amlodipine|losartan|telmisartan|atenolol|metoprolol|hydrochlorothiazide/, tests: ["Systolic BP"], label: "blood pressure" },
  { match: /statin|atorva|rosuva|simva|prava/, tests: ["LDL cholesterol"], label: "LDL cholesterol" },
];

const days = (a: string, b: string) => Math.round((Date.parse(b) - Date.parse(a)) / 86_400_000);
export const fmtDate = (iso?: string) => {
  if (!iso) return "undated";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString("en-GB", { month: "short", year: "numeric" });
};
export const fmtDateFull = (iso?: string) => {
  if (!iso) return "undated";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
};
const fmtVal = (v: number, unit?: string) => `${v}${unit === "%" ? "%" : unit ? ` ${unit}` : ""}`;

const docLabel = (docs: SourceDoc[], id: string) => docs.find((d) => d.id === id)?.name ?? id;

/* ---------- main ---------- */

export function analyze(docs: SourceDoc[]): Analysis {
  const ready = docs.filter((d) => d.status === "ready" && d.extraction);
  const labs: LabResult[] = [];
  const meds: Medication[] = [];
  const timeline: TimelineItem[] = [];
  const insights: Insight[] = [];
  let n = 0;
  const uid = (p: string) => `${p}-${++n}`;

  for (const d of ready) {
    const ex = d.extraction!;
    for (const l of ex.labs) labs.push({ ...l, test: canonicalTest(l.test), date: l.date || ex.documentDate || "" });
    for (const m of ex.medications) meds.push({ ...m, name: canonicalMed(m.name), date: m.date || ex.documentDate || "" });
    for (const e of ex.events) {
      timeline.push({ id: uid("ev"), kind: "event", date: e.date || ex.documentDate || "", title: e.title, detail: e.detail, confidence: e.confidence, sources: [e.source] });
    }
  }

  /* Lab timeline items: group by doc+date */
  const labGroups = new Map<string, LabResult[]>();
  for (const l of labs) {
    const k = `${l.source.docId}|${l.date}`;
    labGroups.set(k, [...(labGroups.get(k) ?? []), l]);
  }
  for (const group of labGroups.values()) {
    const parts = group.map((l) => `${l.test} ${l.value !== null ? fmtVal(l.value, l.unit) : (l.rawValue ?? "?")}`);
    timeline.push({
      id: uid("lab"), kind: "lab", date: group[0]!.date,
      title: `${group.length} result${group.length > 1 ? "s" : ""} recorded`,
      detail: parts.join(" · "),
      confidence: minConfidence(...group.map((l) => l.confidence)),
      sources: group.map((l) => l.source),
    });
  }

  /* Medication timeline items */
  for (const m of meds) {
    if (m.action === "continued" || m.action === "mentioned") continue;
    const verb = m.action === "started" ? "started" : m.action === "changed" ? "changed to" : "stopped";
    timeline.push({
      id: uid("med"), kind: "medication", date: m.date,
      title: `${m.name} ${verb}${m.action !== "stopped" && m.dose ? ` ${m.dose}` : ""}${m.frequency && m.action !== "stopped" ? ` ${m.frequency}` : ""}`,
      confidence: m.confidence, sources: [m.source],
    });
  }

  /* Trends: repeated tests */
  const byTest = new Map<string, LabResult[]>();
  for (const l of labs) byTest.set(l.test, [...(byTest.get(l.test) ?? []), l]);
  const trends: TrendSeries[] = [];
  for (const [test, rows] of byTest) {
    const numeric = rows.filter((r) => r.value !== null && r.date).sort((a, b) => a.date.localeCompare(b.date));
    if (numeric.length < 2) continue;
    const refLow = numeric.find((r) => r.refLow != null)?.refLow;
    const refHigh = numeric.find((r) => r.refHigh != null)?.refHigh;
    const points = numeric.map((r) => ({
      date: r.date, value: r.value!, unit: r.unit, confidence: r.confidence, source: r.source,
      outOfRange: (refHigh != null && r.value! > refHigh) || (refLow != null && r.value! < refLow),
    }));
    const first = points[0]!, last = points[points.length - 1]!;
    const delta = +(last.value - first.value).toFixed(2);
    const direction = Math.abs(delta) < 1e-9 ? "flat" : delta > 0 ? "up" : "down";
    trends.push({ test, unit: first.unit, points, delta, direction, refLow, refHigh });

    const worse = (direction === "up" && refHigh != null) || (direction === "down" && refLow != null && last.value < refLow);
    insights.push({
      id: uid("ins"), kind: "insight",
      text: `${test} ${direction === "flat" ? "unchanged at" : direction === "up" ? "rose from" : "fell from"} ${fmtVal(first.value, first.unit)} (${fmtDate(first.date)}) to ${fmtVal(last.value, last.unit)} (${fmtDate(last.date)}) across ${points.length} readings${last.outOfRange ? " — latest outside reference range" : ""}${worse && last.outOfRange ? "; trend is unfavourable" : ""}.`,
      confidence: minConfidence(...points.map((p) => p.confidence)),
      sources: [first.source, last.source], date: last.date,
    });
  }
  trends.sort((a, b) => b.points.length - a.points.length);

  /* Medication history + conflicts */
  const byMed = new Map<string, Medication[]>();
  for (const m of meds) byMed.set(m.name, [...(byMed.get(m.name) ?? []), m]);
  const medications: MedTimelineEntry[] = [];
  for (const [name, rows] of byMed) {
    const sorted = [...rows].sort((a, b) => a.date.localeCompare(b.date));
    let changes = 0, conflict = false;
    for (let i = 1; i < sorted.length; i++) {
      const a = sorted[i - 1]!, b = sorted[i]!;
      const sameRegimen = norm(a.dose ?? "") === norm(b.dose ?? "") && norm(a.frequency ?? "") === norm(b.frequency ?? "");
      if (sameRegimen) continue;
      if (b.action === "changed" || b.action === "started" || b.action === "stopped") { changes++; continue; }
      // "continued" but regimen differs from last known → inconsistency
      if (a.source.docId !== b.source.docId) {
        conflict = true;
        const text = `${name} regimen conflicts: ${a.dose ?? "?"} ${a.frequency ?? ""} (${docLabel(docs, a.source.docId)}) vs ${b.dose ?? "?"} ${b.frequency ?? ""} (${docLabel(docs, b.source.docId)}) with no documented change.`;
        insights.push({ id: uid("ins"), kind: "inconsistency", text, confidence: minConfidence(a.confidence, b.confidence), sources: [a.source, b.source], date: b.date });
        timeline.push({ id: uid("alert"), kind: "alert", severity: "signal", date: b.date, title: `${name} dose inconsistent across documents`, detail: `${a.dose ?? "?"} ${a.frequency ?? ""} → ${b.dose ?? "?"} ${b.frequency ?? ""} without a recorded change`, confidence: minConfidence(a.confidence, b.confidence), sources: [a.source, b.source] });
      }
    }
    for (const m of sorted) {
      if (!m.dose && m.action !== "stopped") {
        insights.push({ id: uid("ins"), kind: "gap", text: `${name} is recorded without a dose in ${docLabel(docs, m.source.docId)}.`, confidence: m.confidence, sources: [m.source], date: m.date });
      }
    }
    medications.push({ name, records: sorted, changes, conflict, firstDate: sorted[0]!.date, lastDate: sorted[sorted.length - 1]!.date });
  }
  medications.sort((a, b) => a.firstDate.localeCompare(b.firstDate));

  /* Relationships: medication change → downstream test movement */
  for (const m of meds) {
    if (m.action !== "started" && m.action !== "changed") continue;
    const target = MED_TARGETS.find((t) => t.match.test(m.name.toLowerCase()));
    if (!target) continue;
    for (const test of target.tests) {
      const series = trends.find((t) => t.test === test) ?? (byTest.get(test) ? { points: (byTest.get(test) ?? []).filter((r) => r.value !== null).map((r) => ({ date: r.date, value: r.value!, unit: r.unit, confidence: r.confidence, source: r.source })) } : null);
      if (!series) continue;
      const before = [...series.points].filter((p) => p.date <= m.date && days(p.date, m.date) <= 400).pop();
      const after = series.points.find((p) => p.date > m.date && days(m.date, p.date) <= 500);
      if (!before || !after) continue;
      const d = +(after.value - before.value).toFixed(2);
      const dir = d === 0 ? "was unchanged" : d < 0 ? "fell" : "rose";
      insights.push({
        id: uid("ins"), kind: "link",
        text: `${m.name} ${m.action} ${m.dose ?? ""} (${fmtDate(m.date)}) → ${test} ${dir} ${fmtVal(before.value, before.unit)} → ${fmtVal(after.value, after.unit)} by ${fmtDate(after.date)}${d > 0 && test !== "Hemoglobin" ? " — response not yet seen" : ""}.`,
        confidence: minConfidence(m.confidence, before.confidence, after.confidence),
        sources: [m.source, before.source, after.source], date: after.date,
      });
    }
  }

  /* Same-visit cross-links: BP elevated + antihypertensive started */
  /* Gaps: overdue repeat tests */
  const dates = ready.map((d) => d.extraction!.documentDate).filter(Boolean) as string[];
  const allDates = [...dates, ...labs.map((l) => l.date), ...meds.map((m) => m.date)].filter(Boolean).sort();
  const start = allDates[0], end = allDates[allDates.length - 1];
  if (end) {
    for (const [test, interval] of Object.entries(EXPECTED_INTERVAL)) {
      const rows = byTest.get(test);
      if (!rows?.length) continue;
      const last = [...rows].sort((a, b) => a.date.localeCompare(b.date)).pop()!;
      const gap = days(last.date, end);
      if (gap > interval) {
        insights.push({ id: uid("ins"), kind: "gap", text: `No ${test} on file since ${fmtDate(last.date)} — ${gap} days, expected every ~${interval}.`, confidence: "high", sources: [last.source], date: end });
        timeline.push({ id: uid("alert"), kind: "alert", severity: "warn", date: end, title: `${test} not on file`, detail: `Last value ${fmtDate(last.date)} · gap in series`, confidence: "high", sources: [last.source] });
      }
    }
  }

  /* Identity inconsistencies */
  const identity: PatientIdentity = {};
  const idSources: Record<string, Map<string, Provenance>> = { name: new Map(), sex: new Map(), mrn: new Map() };
  for (const d of ready) {
    const p = d.extraction!.patient;
    if (!p) continue;
    for (const k of ["name", "sex", "mrn"] as const) {
      const v = p[k];
      if (!v) continue;
      let key = norm(String(v));
      if (k === "sex") key = key.startsWith("f") ? "female" : key.startsWith("m") ? "male" : key;
      if (!idSources[k]!.has(key)) idSources[k]!.set(key, { docId: d.id, page: 1 });
      if (!identity[k]) identity[k] = v;
    }
    if (p.age && !identity.age) identity.age = p.age;
  }
  for (const [k, map] of Object.entries(idSources)) {
    if (map.size > 1) {
      const vals = [...map.keys()].join(" vs ");
      insights.push({ id: uid("ins"), kind: "inconsistency", text: `Patient ${k} differs across documents (${vals}). Verify these records belong to the same person.`, confidence: "medium", sources: [...map.values()] });
    }
  }

  /* Uncertainty notes */
  for (const l of labs) {
    if (l.confidence === "low" || l.value === null) {
      insights.push({ id: uid("ins"), kind: "uncertainty", text: `${l.test} value ambiguous${l.rawValue ? ` ("${l.rawValue}")` : ""} in ${docLabel(docs, l.source.docId)} — excluded from trends, flagged for review.`, confidence: "low", sources: [l.source], date: l.date });
    }
  }
  for (const d of ready) {
    for (const u of d.extraction!.uncertainties) {
      if (insights.some((i) => i.kind === "uncertainty" && i.text.includes(u))) continue;
      insights.push({ id: uid("ins"), kind: "uncertainty", text: u, confidence: "low", sources: [{ docId: d.id }] });
    }
    if (!d.extraction!.documentDate) {
      insights.push({ id: uid("ins"), kind: "gap", text: `${d.name} has no identifiable date; its findings cannot be placed on the timeline reliably.`, confidence: "medium", sources: [{ docId: d.id }] });
    }
  }

  timeline.sort((a, b) => b.date.localeCompare(a.date));
  const order: Record<Insight["kind"], number> = { inconsistency: 0, gap: 1, link: 2, insight: 3, uncertainty: 4 };
  insights.sort((a, b) => order[a.kind] - order[b.kind]);

  const spanLabel = start && end ? spanText(start, end) : "—";
  const all = [...labs.map((l) => l.confidence), ...meds.map((m) => m.confidence)];
  const avg = all.length ? all.reduce((s, c) => s + RANK[c], 0) / all.length : 3;
  const overallConfidence: Confidence = avg >= 2.6 ? "high" : avg >= 1.8 ? "medium" : "low";

  return { timeline, trends, medications, insights, identity, span: { start, end, label: spanLabel }, overallConfidence };
}

function spanText(a: string, b: string) {
  const total = Math.max(0, days(a, b));
  const y = Math.floor(total / 365), m = Math.floor((total % 365) / 30);
  return y ? `${y}y ${m}m` : `${m}m`;
}
