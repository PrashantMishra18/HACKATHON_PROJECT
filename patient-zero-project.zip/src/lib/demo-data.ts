import type { SourceDoc } from "./types";

const P = { name: "A. Okafor", age: 54, sex: "Female", mrn: "004-2291" };

export const DEMO_DOCS: SourceDoc[] = [
  {
    id: "d1",
    name: "Endocrinology visit note — Mar 2021.pdf",
    status: "ready",
    extraction: {
      patient: P,
      documentDate: "2021-03-14",
      documentType: "visit",
      summary: "Initial endocrinology consult. New diagnosis of type 2 diabetes; metformin initiated.",
      labs: [
        { test: "HbA1c", value: 6.2, unit: "%", refLow: 4, refHigh: 5.6, date: "2021-03-14", confidence: "high", source: { docId: "d1", page: 1, quote: "HbA1c 6.2%" } },
        { test: "Systolic BP", value: 122, unit: "mmHg", refLow: 90, refHigh: 130, date: "2021-03-14", confidence: "high", source: { docId: "d1", page: 1, quote: "BP 122/78" } },
        { test: "Diastolic BP", value: 78, unit: "mmHg", refLow: 60, refHigh: 85, date: "2021-03-14", confidence: "high", source: { docId: "d1", page: 1, quote: "BP 122/78" } },
      ],
      medications: [
        { name: "Metformin", dose: "500 mg", frequency: "BID", action: "started", date: "2021-03-14", confidence: "high", source: { docId: "d1", page: 2, quote: "Start Metformin 500 mg twice daily" } },
      ],
      events: [
        { kind: "diagnosis", title: "Type 2 diabetes mellitus diagnosed", detail: "Based on HbA1c and fasting glucose criteria.", date: "2021-03-14", confidence: "high", source: { docId: "d1", page: 1 } },
      ],
      uncertainties: [],
    },
  },
  {
    id: "d2",
    name: "Laboratory report — Aug 2022.pdf",
    status: "ready",
    extraction: {
      patient: P,
      documentDate: "2022-08-09",
      documentType: "lab",
      summary: "Routine metabolic and lipid panel.",
      labs: [
        { test: "HbA1c", value: 6.8, unit: "%", refLow: 4, refHigh: 5.6, date: "2022-08-09", confidence: "high", source: { docId: "d2", page: 1 } },
        { test: "Fasting glucose", value: 131, unit: "mg/dL", refLow: 70, refHigh: 99, date: "2022-08-09", confidence: "high", source: { docId: "d2", page: 1 } },
        { test: "LDL cholesterol", value: 138, unit: "mg/dL", refLow: 0, refHigh: 100, date: "2022-08-09", confidence: "high", source: { docId: "d2", page: 2 } },
        { test: "Creatinine", value: 0.9, unit: "mg/dL", refLow: 0.6, refHigh: 1.2, date: "2022-08-09", confidence: "high", source: { docId: "d2", page: 2 } },
      ],
      medications: [],
      events: [],
      uncertainties: [],
    },
  },
  {
    id: "d3",
    name: "Prescription — Aug 2022.jpg",
    status: "ready",
    extraction: {
      patient: P,
      documentDate: "2022-08-22",
      documentType: "prescription",
      summary: "Handwritten prescription: metformin uptitrated, statin added.",
      labs: [],
      medications: [
        { name: "Metformin", dose: "1000 mg", frequency: "BID", action: "changed", date: "2022-08-22", confidence: "high", source: { docId: "d3", page: 1, quote: "Tab Metformin 1000 mg 1-0-1" } },
        { name: "Atorvastatin", dose: "20 mg", frequency: "OD", action: "started", date: "2022-08-22", confidence: "medium", source: { docId: "d3", page: 1, quote: "Tab Atorva 20 HS (handwriting partially legible)" } },
      ],
      events: [],
      uncertainties: ["Statin dose read as 20 mg; '20' could be '40' in handwriting."],
    },
  },
  {
    id: "d4",
    name: "Abdominal ultrasound — Jun 2023.pdf",
    status: "ready",
    extraction: {
      patient: { name: "A. Okafor", age: 53, sex: "Male", mrn: "004-2291" },
      documentDate: "2023-06-05",
      documentType: "imaging",
      summary: "Ultrasound abdomen with incidental lipid values noted from an attached slip.",
      labs: [
        { test: "LDL cholesterol", value: null, rawValue: "1?2 mg/dL", unit: "mg/dL", date: "2023-06-05", confidence: "low", source: { docId: "d4", page: 2, quote: "LDL 1?2 (smudged)" } },
      ],
      medications: [],
      events: [
        { kind: "imaging", title: "Grade 1 hepatic steatosis", detail: "Mild diffuse increase in hepatic echogenicity. No focal lesion.", date: "2023-06-05", confidence: "high", source: { docId: "d4", page: 1 } },
      ],
      uncertainties: ["Patient sex recorded as Male on this report; other documents state Female."],
    },
  },
  {
    id: "d5",
    name: "GP visit note — Jan 2024.pdf",
    status: "ready",
    extraction: {
      patient: P,
      documentDate: "2024-01-11",
      documentType: "visit",
      summary: "Elevated blood pressure; antihypertensive and low-dose aspirin initiated.",
      labs: [
        { test: "HbA1c", value: 7.1, unit: "%", refLow: 4, refHigh: 5.6, date: "2024-01-11", confidence: "high", source: { docId: "d5", page: 1 } },
        { test: "Systolic BP", value: 158, unit: "mmHg", refLow: 90, refHigh: 130, date: "2024-01-11", confidence: "high", source: { docId: "d5", page: 1, quote: "BP 158/96" } },
        { test: "Diastolic BP", value: 96, unit: "mmHg", refLow: 60, refHigh: 85, date: "2024-01-11", confidence: "high", source: { docId: "d5", page: 1, quote: "BP 158/96" } },
      ],
      medications: [
        { name: "Lisinopril", dose: "10 mg", frequency: "OD", action: "started", date: "2024-01-11", confidence: "high", source: { docId: "d5", page: 2 } },
        { name: "Aspirin", dose: "75 mg", frequency: "OD", action: "started", date: "2024-01-11", confidence: "high", source: { docId: "d5", page: 2 } },
        { name: "Metformin", dose: "1000 mg", frequency: "OD", action: "continued", date: "2024-01-11", confidence: "medium", source: { docId: "d5", page: 2, quote: "Continue Metformin 1 g daily" } },
        { name: "Atorvastatin", dose: "20 mg", frequency: "OD", action: "continued", date: "2024-01-11", confidence: "high", source: { docId: "d5", page: 2 } },
      ],
      events: [
        { kind: "visit", title: "GP follow-up: hypertension noted", detail: "Two elevated readings in clinic; home monitoring advised.", date: "2024-01-11", confidence: "high", source: { docId: "d5", page: 1 } },
      ],
      uncertainties: [],
    },
  },
  {
    id: "d6",
    name: "Laboratory report — Sep 2024.pdf",
    status: "ready",
    extraction: {
      patient: P,
      documentDate: "2024-09-03",
      documentType: "lab",
      summary: "Follow-up metabolic panel. HbA1c not included in this order.",
      labs: [
        { test: "Fasting glucose", value: 141, unit: "mg/dL", refLow: 70, refHigh: 99, date: "2024-09-03", confidence: "high", source: { docId: "d6", page: 1 } },
        { test: "Creatinine", value: 1.1, unit: "mg/dL", refLow: 0.6, refHigh: 1.2, date: "2024-09-03", confidence: "high", source: { docId: "d6", page: 1 } },
        { test: "LDL cholesterol", value: 118, unit: "mg/dL", refLow: 0, refHigh: 100, date: "2024-09-03", confidence: "high", source: { docId: "d6", page: 2 } },
      ],
      medications: [],
      events: [],
      uncertainties: [],
    },
  },
];
