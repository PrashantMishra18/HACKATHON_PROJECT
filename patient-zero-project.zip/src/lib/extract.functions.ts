import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { Extraction } from "./types";

const inputSchema = z.object({
  name: z.string().min(1),
  mimeType: z.string(),
  /** data: URL for PDFs/images, or plain text for .txt files */
  dataUrl: z.string().optional(),
  text: z.string().optional(),
});

const conf = z.enum(["high", "medium", "low"]).catch("medium");
const prov = z.object({
  page: z.number().nullish(),
  quote: z.string().nullish(),
}).partial().catch({});
const dateStr = z.string().nullish().transform((v) => (v && /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : undefined));

const extractionSchema = z.object({
  patient: z.object({
    name: z.string().nullish(),
    age: z.number().nullish(),
    sex: z.string().nullish(),
    mrn: z.string().nullish(),
  }).partial().nullish(),
  documentDate: dateStr,
  documentType: z.enum(["lab", "prescription", "imaging", "visit", "discharge", "other"]).catch("other"),
  summary: z.string().catch(""),
  labs: z.array(z.object({
    test: z.string(),
    value: z.number().nullish(),
    rawValue: z.string().nullish(),
    unit: z.string().nullish(),
    refLow: z.number().nullish(),
    refHigh: z.number().nullish(),
    date: dateStr,
    confidence: conf,
    source: prov,
  })).catch([]),
  medications: z.array(z.object({
    name: z.string(),
    dose: z.string().nullish(),
    frequency: z.string().nullish(),
    action: z.enum(["started", "continued", "changed", "stopped", "mentioned"]).catch("mentioned"),
    date: dateStr,
    confidence: conf,
    source: prov,
  })).catch([]),
  events: z.array(z.object({
    kind: z.enum(["visit", "diagnosis", "imaging", "procedure", "symptom", "note"]).catch("note"),
    title: z.string(),
    detail: z.string().nullish(),
    date: dateStr,
    confidence: conf,
    source: prov,
  })).catch([]),
  uncertainties: z.array(z.string()).catch([]),
});

const SYSTEM = `You are a meticulous clinical-records extraction engine. You read ONE medical document (lab report, prescription, imaging report, visit/discharge note) and return STRICT JSON only — no prose, no markdown fences.

Schema:
{
 "patient": {"name": string|null, "age": number|null, "sex": string|null, "mrn": string|null},
 "documentDate": "YYYY-MM-DD"|null,
 "documentType": "lab"|"prescription"|"imaging"|"visit"|"discharge"|"other",
 "summary": string (one sentence),
 "labs": [{"test": string, "value": number|null, "rawValue": string|null, "unit": string|null, "refLow": number|null, "refHigh": number|null, "date": "YYYY-MM-DD"|null, "confidence": "high"|"medium"|"low", "source": {"page": number|null, "quote": string|null}}],
 "medications": [{"name": string, "dose": string|null, "frequency": string|null, "action": "started"|"continued"|"changed"|"stopped"|"mentioned", "date": "YYYY-MM-DD"|null, "confidence": "high"|"medium"|"low", "source": {"page": number|null, "quote": string|null}}],
 "events": [{"kind": "visit"|"diagnosis"|"imaging"|"procedure"|"symptom"|"note", "title": string, "detail": string|null, "date": "YYYY-MM-DD"|null, "confidence": "high"|"medium"|"low", "source": {"page": number|null, "quote": string|null}}],
 "uncertainties": [string]
}

Rules:
- Record blood pressure as two labs: "Systolic BP" and "Diastolic BP" (unit mmHg).
- Use canonical test names (HbA1c, Fasting glucose, LDL cholesterol, Creatinine, Hemoglobin, TSH...).
- Medication name = generic drug name only; put strength in "dose" (e.g. "500 mg") and schedule in "frequency" (OD, BID, TID, HS...).
- If a value is illegible or ambiguous, set value null, put the raw text in rawValue and confidence "low". Never guess.
- Every item gets a "source" with page number and a short verbatim quote when possible.
- List anything uncertain, contradictory, or missing (undated document, no patient name, illegible dose) in "uncertainties".
- Do NOT invent findings that are not in the document.`;

export const extractDocument = createServerFn({ method: "POST" })
  .inputValidator((d) => inputSchema.parse(d))
  .handler(async ({ data }): Promise<Extraction> => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) throw new Error("AI is not configured for this project.");

    const content: Record<string, unknown>[] = [
      { type: "input_text", text: `Document filename: ${data.name}\nExtract this document.` },
    ];
    if (data.text) {
      content.push({ type: "input_text", text: `--- DOCUMENT TEXT ---\n${data.text.slice(0, 60_000)}` });
    } else if (data.dataUrl && data.mimeType === "application/pdf") {
      content.push({ type: "input_file", filename: data.name, file_data: data.dataUrl });
    } else if (data.dataUrl && data.mimeType.startsWith("image/")) {
      content.push({ type: "input_image", image_url: data.dataUrl });
    } else {
      throw new Error("Unsupported file type. Upload a PDF, image, or plain-text file.");
    }

    const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "openai/gpt-6-astra",
        reasoning: { effort: "low" },
        input: [
          { role: "system", content: [{ type: "input_text", text: SYSTEM }] },
          { role: "user", content },
        ],
      }),
    });

    if (!res.ok) {
      const body = await res.text().catch(() => "");
      let msg = `Extraction failed (${res.status}).`;
      try { msg = JSON.parse(body)?.error?.message ?? JSON.parse(body)?.message ?? msg; } catch { /* keep default */ }
      if (res.status === 402) msg = "AI credits exhausted. Add credits to your workspace to continue extracting.";
      if (res.status === 429) msg = "Rate limited by the AI service. Please wait a moment and retry.";
      throw new Error(msg);
    }

    const json = (await res.json()) as { output?: { type: string; content?: { type: string; text?: string }[] }[] };
    const text = json.output?.filter((o) => o.type === "message").flatMap((o) => o.content ?? []).find((c) => c.type === "output_text")?.text ?? "";
    const raw = text.trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
    let parsed: unknown;
    try { parsed = JSON.parse(raw); } catch { throw new Error("The AI returned an unreadable extraction. Try re-uploading the document."); }
    const ex = extractionSchema.parse(parsed);

    const nz = <T,>(v: T | null | undefined): T | undefined => (v == null ? undefined : v);
    const src = (s: { page?: number | null | undefined; quote?: string | null | undefined }) => ({ docId: "", page: nz(s.page), quote: nz(s.quote) });

    return {
      patient: ex.patient ? { name: nz(ex.patient.name), age: nz(ex.patient.age), sex: nz(ex.patient.sex), mrn: nz(ex.patient.mrn) } : undefined,
      documentDate: ex.documentDate,
      documentType: ex.documentType,
      summary: ex.summary,
      labs: ex.labs.map((l) => ({ test: l.test, value: l.value ?? null, rawValue: nz(l.rawValue), unit: nz(l.unit), refLow: nz(l.refLow), refHigh: nz(l.refHigh), date: l.date ?? ex.documentDate ?? "", confidence: l.confidence, source: src(l.source) })),
      medications: ex.medications.map((m) => ({ name: m.name, dose: nz(m.dose), frequency: nz(m.frequency), action: m.action, date: m.date ?? ex.documentDate ?? "", confidence: m.confidence, source: src(m.source) })),
      events: ex.events.map((e) => ({ kind: e.kind, title: e.title, detail: nz(e.detail), date: e.date ?? ex.documentDate ?? "", confidence: e.confidence, source: src(e.source) })),
      uncertainties: ex.uncertainties,
    };
  });
